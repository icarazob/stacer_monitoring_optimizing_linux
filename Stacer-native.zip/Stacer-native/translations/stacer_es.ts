<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="es_ES">
<context>
    <name>APTSourceEdit</name>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_edit.ui" line="14"/>
        <source>APT Repository Edit</source>
        <translation>Editar repositorio APT</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_edit.ui" line="38"/>
        <source>APT Repository</source>
        <translation>Repositorio APT</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_edit.ui" line="48"/>
        <source>Components</source>
        <translation>Componentes</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_edit.ui" line="55"/>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_edit.ui" line="71"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_edit.ui" line="87"/>
        <source>Fields cannot be left blank. </source>
        <translation>Los campos no se pueden dejar en blanco. </translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_edit.ui" line="94"/>
        <source>URI</source>
        <translation>URI</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_edit.ui" line="110"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_edit.ui" line="133"/>
        <source>Distribution</source>
        <translation>Distribución</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_edit.ui" line="152"/>
        <source>Source</source>
        <translation>Fuente</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_edit.ui" line="177"/>
        <source>Binary</source>
        <translation>Binario</translation>
    </message>
</context>
<context>
    <name>APTSourceManagerPage</name>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.ui" line="188"/>
        <source>Search...</source>
        <translation>Buscar...</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.ui" line="226"/>
        <source>Edit</source>
        <translation>Editar</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.ui" line="14"/>
        <source>APT Repository Manager</source>
        <translation>Administrador de repositorios APT</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.ui" line="125"/>
        <source>Not Found APT Repositories</source>
        <translation>Repositorios APT no encontrados</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.ui" line="269"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.ui" line="308"/>
        <source>Enable Source</source>
        <translation>Habilitar fuente</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.ui" line="338"/>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.cpp" line="86"/>
        <source>Add Repository</source>
        <translation>Agregar repositorio</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.ui" line="371"/>
        <source>Cancel</source>
        <translation>Cancelar</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.ui" line="419"/>
        <source>Select to delete or edit.</source>
        <translation>Selecciona para eliminar o editar</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.cpp" line="25"/>
        <source>example %1</source>
        <translation>ejemplo %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.cpp" line="59"/>
        <source>APT Repositories (%1)</source>
        <translation>Repositorios APT (1)</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.cpp" line="66"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
</context>
<context>
    <name>APTSourceRepositoryItem</name>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_repository_item.cpp" line="34"/>
        <source>%1 (Source Code)</source>
        <translation>%1 (Código fuente)</translation>
    </message>
</context>
<context>
    <name>App</name>
    <message>
        <location filename="../stacer/app.ui" line="101"/>
        <source>Dashboard</source>
        <translation>Tablero</translation>
    </message>
    <message>
        <location filename="../stacer/app.ui" line="135"/>
        <source>Startup Apps</source>
        <translation>Aplicaciones de inicio</translation>
    </message>
    <message>
        <location filename="../stacer/app.ui" line="163"/>
        <source>System Cleaner</source>
        <translation>Limpiador del Sistema</translation>
    </message>
    <message>
        <location filename="../stacer/app.ui" line="306"/>
        <source>APT Repository Manager</source>
        <translation>Administrador de repositorios APT</translation>
    </message>
    <message>
        <location filename="../stacer/app.ui" line="250"/>
        <source>Uninstaller</source>
        <translation>Desinstalador</translation>
    </message>
    <message>
        <location filename="../stacer/app.ui" line="278"/>
        <source>Resources</source>
        <translation>Recursos</translation>
    </message>
    <message>
        <location filename="../stacer/app.ui" line="222"/>
        <source>Processes</source>
        <translation>Procesos</translation>
    </message>
    <message>
        <location filename="../stacer/app.ui" line="194"/>
        <source>Services</source>
        <translation>Servicios</translation>
    </message>
    <message>
        <location filename="../stacer/app.ui" line="334"/>
        <source>Gnome Settings</source>
        <translation>Ajustes de Gnome</translation>
    </message>
    <message>
        <location filename="../stacer/app.ui" line="362"/>
        <source>Settings</source>
        <translation>Ajustes</translation>
    </message>
    <message>
        <location filename="../stacer/app.ui" line="403"/>
        <source>Feedback</source>
        <translation>Comentarios</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="111"/>
        <source>Quit</source>
        <translation>Salir</translation>
    </message>
</context>
<context>
    <name>AppearanceSettings</name>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="44"/>
        <source>Screen Applications</source>
        <translation>Aplicaciones de pantalla</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="74"/>
        <source>Screen Reader</source>
        <translation>Lector de pantalla</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="100"/>
        <source>Screen Keyboard</source>
        <translation>Teclado de pantalla</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="136"/>
        <source>Background Image Mode</source>
        <translation>Modo de fondo de pantalla</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="166"/>
        <source>Desktop Mode</source>
        <translation>Modo de escritorio</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="204"/>
        <source>Login Mode</source>
        <translation>Modo de inicio de sesión</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="252"/>
        <source>Icons</source>
        <translation>Íconos</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="282"/>
        <source>Home Icon</source>
        <translation>Ícono de inicio</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="308"/>
        <source>Trash Icon</source>
        <translation>Ícono de papelera</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="321"/>
        <source>Mounted Volumes Icon</source>
        <translation>Ícono de volúmenes montados</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="347"/>
        <source>Show Desktop Icons</source>
        <translation>Mostrar los íconos del escritorio</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="373"/>
        <source>Network Icon</source>
        <translation>Ícono de red</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.cpp" line="71"/>
        <source>None</source>
        <translation>Ninguno</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.cpp" line="71"/>
        <source>Wallpaper</source>
        <translation>Fondo de pantalla</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.cpp" line="71"/>
        <source>Centered</source>
        <translation>Centrado</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.cpp" line="72"/>
        <source>Scaled</source>
        <translation>Escalado</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.cpp" line="72"/>
        <source>Stretched</source>
        <translation>Alargado</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.cpp" line="72"/>
        <source>Zoom</source>
        <translation>Ampliado</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.cpp" line="72"/>
        <source>Spanned</source>
        <translation>Extendido</translation>
    </message>
</context>
<context>
    <name>DashboardPage</name>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.ui" line="20"/>
        <source>Dashboard</source>
        <translation>Tablero</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.ui" line="156"/>
        <source>SYSTEM INFO</source>
        <translation>INFORMACIÓN DEL SISTEMA</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.ui" line="230"/>
        <source>There are update currently available.</source>
        <translation>Actualmente hay actualizaciones disponibles.</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.ui" line="246"/>
        <source>Download</source>
        <translation>Descargar</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="14"/>
        <source>CPU</source>
        <translation>CPU</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="15"/>
        <source>MEMORY</source>
        <translation>MEMORIA</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="16"/>
        <source>DISK</source>
        <translation>DISCO</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="17"/>
        <source>DOWNLOAD</source>
        <translation>DESCARGAR</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="18"/>
        <source>UPLOAD</source>
        <translation>SUBIR</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="111"/>
        <source>Hostname: %1</source>
        <translation>Nombre de host: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="112"/>
        <source>Platform: %1</source>
        <translation>Plataforma: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="113"/>
        <source>Distribution: %1</source>
        <translation>Distribución: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="114"/>
        <source>Kernel Release: %1</source>
        <translation>Versión del kernel: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="115"/>
        <source>CPU Model: %1</source>
        <translation>Modelo de CPU: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="117"/>
        <source>CPU Speed: %1</source>
        <translation>Velocidad de la CPU: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="116"/>
        <source>CPU Core: %1</source>
        <translation>Núcleo de la CPU:%1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="133"/>
        <source>High CPU Usage</source>
        <translation>Uso elevado de CPU</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="134"/>
        <source>The amount of CPU used is over %1%.</source>
        <translation>La cantidad de CPU usada está sobre el %1%.</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="162"/>
        <source>High Memory Usage</source>
        <translation>Uso elevado de memoria</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="163"/>
        <source>The amount of memory used is over %1%.</source>
        <translation>La cantidad de memoria usada está sobre el %1%.</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="202"/>
        <source>High Disk Usage</source>
        <translation>Uso elevado del disco</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="203"/>
        <source>The amount of disk used is over %1%.</source>
        <translation>La cantidad de disco usado está sobre el %1%.</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="241"/>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="245"/>
        <source>Total: %1</source>
        <translation>Total: %1</translation>
    </message>
</context>
<context>
    <name>Feedback</name>
    <message>
        <location filename="../stacer/feedback.ui" line="14"/>
        <source>Feedback</source>
        <translation>Comentarios</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.ui" line="38"/>
        <source>Name</source>
        <translation>Nombre</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.ui" line="45"/>
        <source>Email Address</source>
        <translation>Dirección de correo electrónico</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.ui" line="68"/>
        <source>Send</source>
        <translation>Enviar</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.ui" line="94"/>
        <source>Message</source>
        <translation>Mensaje</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.ui" line="104"/>
        <source>Send a Feedback</source>
        <translation>Envía un comentario</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.cpp" line="46"/>
        <source>Email address is not valid !</source>
        <translation>¡La dirección de correo electrónico no es válida!</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.cpp" line="51"/>
        <source>Your message must be at least 25 characters !</source>
        <translation>¡Tu mensaje debe de tener al menos 25 caracteres!</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.cpp" line="61"/>
        <source>Sending..</source>
        <translation>Enviando...</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.cpp" line="79"/>
        <source>&lt;font color=&apos;#2ecc71&apos;&gt;Your Feedback has been successfully sended.&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;#2ecc71&apos;&gt;Tu comentario ha sido enviado correctamente.&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.cpp" line="81"/>
        <location filename="../stacer/feedback.cpp" line="86"/>
        <source>Something went wrong, try again !</source>
        <translation>¡Algo salió mal, intenta de nuevo!</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.cpp" line="89"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.cpp" line="94"/>
        <source>Fields cannot be left blank !</source>
        <translation>¡Los campos no se pueden dejar en blanco!</translation>
    </message>
</context>
<context>
    <name>GnomeSettingsPage</name>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/gnome_settings_page.ui" line="14"/>
        <source>Gnome Settings</source>
        <translation>Ajustes de Gnome</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/gnome_settings_page.ui" line="49"/>
        <source>Unity Settings</source>
        <translation>Ajustes de Unity</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/gnome_settings_page.ui" line="81"/>
        <source>Window Manager</source>
        <translation>Administrador de ventanas</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/gnome_settings_page.ui" line="110"/>
        <source>Appearance</source>
        <translation>Apariencia</translation>
    </message>
</context>
<context>
    <name>ProcessesPage</name>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.ui" line="14"/>
        <location filename="../stacer/Pages/Processes/processes_page.ui" line="55"/>
        <source>Processes</source>
        <translation>Procesos</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.ui" line="71"/>
        <source>All Processes</source>
        <translation>Todos los procesos</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.ui" line="96"/>
        <source>Search...</source>
        <translation>Buscar...</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.ui" line="217"/>
        <source>End Process</source>
        <translation>Proceso final</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="27"/>
        <source>User</source>
        <translation>Usuario</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="26"/>
        <source>Resident Memory</source>
        <translation>Memoria residente</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="26"/>
        <source>%Memory</source>
        <translation>%Memoria</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="26"/>
        <source>Virtual Memory</source>
        <translation>Memoria virtual</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="27"/>
        <source>Start Time</source>
        <translation>Hora de inicio</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="27"/>
        <source>State</source>
        <translation>Estado</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="27"/>
        <source>Group</source>
        <translation>Grupo</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="28"/>
        <source>Nice</source>
        <translation>Prioridad</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="28"/>
        <source>CPU Time</source>
        <translation>Tiempo de CPU</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="28"/>
        <source>Session</source>
        <translation>Sesión</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="28"/>
        <source>Process</source>
        <translation>Proceso</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="119"/>
        <source>Processes (%1)</source>
        <translation>Procesos (%1)</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="210"/>
        <source>Refresh (%1)</source>
        <translation>Refrescar (%1)</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../stacer/Managers/setting_manager.cpp" line="61"/>
        <source>Dashboard</source>
        <translation>Tablero</translation>
    </message>
</context>
<context>
    <name>ResourcesPage</name>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="14"/>
        <source>History of CPU</source>
        <translation>Historial de la CPU</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="15"/>
        <source>History of CPU Load Averages</source>
        <translation>Historial de los proceso de carga de la CPU</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="16"/>
        <source>History of Disk Read Write</source>
        <translation>Historial de lectura y escritura en disco</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="17"/>
        <source>History of Memory</source>
        <translation>Historial de memoria</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="18"/>
        <source>History of Network</source>
        <translation>Historial de red</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="75"/>
        <source>Read: %1/s Total: %2</source>
        <translation>Lectura: %1/s Total: %2</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="81"/>
        <source>Write: %1/s Total: %2</source>
        <translation>Escritura: %1/s Total: %2</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="118"/>
        <source>%1 Minute Average: %2</source>
        <translation>%1 promedio por minuto</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="164"/>
        <source>Download: %1/s Total: %2</source>
        <translation>Descarga: %1/s Total: %2</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="169"/>
        <source>Upload: %1/s  Total: %2</source>
        <translation>Subida: %1/s Total: %2</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="213"/>
        <source>Swap: %1 (%2%) %3</source>
        <translation>Intercambio: %1 (%2%) %3</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="222"/>
        <source>Memory: %1 (%2%) %3</source>
        <translation>Memoria: %1 (%2%) %3</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.ui" line="14"/>
        <source>Resources</source>
        <translation>Recursos</translation>
    </message>
</context>
<context>
    <name>ServicesPage</name>
    <message>
        <location filename="../stacer/Pages/Services/services_page.ui" line="14"/>
        <source>Services</source>
        <translation>Servicios</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.ui" line="137"/>
        <source>Startup at boot ?</source>
        <translation>Inicio en el arranque ?</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.ui" line="190"/>
        <source>Running Now ?</source>
        <translation>Ejecutado ahora ?</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.ui" line="244"/>
        <source>Not Found System Service</source>
        <translation>Servicio del sistema no encontrado</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.cpp" line="27"/>
        <source>Running Status</source>
        <translation>Estado de ejecución</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.cpp" line="27"/>
        <source>Running</source>
        <translation>Ejecutado</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.cpp" line="27"/>
        <source>Not Running</source>
        <translation>No ejecutado</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.cpp" line="28"/>
        <source>Startup Status</source>
        <translation>Estado de inicio</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.cpp" line="28"/>
        <source>Enabled</source>
        <translation>Habilitado</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.cpp" line="28"/>
        <source>Disabled</source>
        <translation>Deshabilitado</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.cpp" line="75"/>
        <source>System Services (%1)</source>
        <translation>Servicios del Sistema (%1)</translation>
    </message>
</context>
<context>
    <name>SettingsPage</name>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="20"/>
        <source>Settings</source>
        <translation>Ajustes</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="110"/>
        <source>Memory Percent</source>
        <translation>Porcentaje de memoria</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="204"/>
        <source>Disk Percent</source>
        <translation>Porcentaje de disco</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="233"/>
        <source>Disks</source>
        <translation>Discos</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="246"/>
        <source>Language</source>
        <translation>Idioma</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="259"/>
        <source>Autostart Stacer</source>
        <translation>Iniciar Stacer automáticamente</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="317"/>
        <source>Alert messages (Show a warning after the specified percentage)</source>
        <translation>Mensajes de alerta (mostrar una advertencia después del porcentaje especificado)</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="422"/>
        <source>Start Page</source>
        <translation>Página de inicio</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="301"/>
        <source>CPU Percent</source>
        <translation>Porcentaje de CPU</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="324"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Created by &lt;a href=&quot;https://github.com/oguzhaninan&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#007af4;&quot;&gt;Oğuzhan İNAN&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Creado por &lt;a href=&quot;https://github.com/oguzhaninan&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#007af4;&quot;&gt;Oğuzhan İNAN&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="355"/>
        <source>Donate</source>
        <translation>Donar</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="97"/>
        <source>Theme</source>
        <translation>Tema</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.cpp" line="74"/>
        <source>Dashboard</source>
        <translation>Tablero</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.cpp" line="74"/>
        <source>Startup Apps</source>
        <translation>Aplicaciones de inicio</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.cpp" line="74"/>
        <source>System Cleaner</source>
        <translation>Limpiador del Sistema</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.cpp" line="75"/>
        <source>Services</source>
        <translation>Servicios</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.cpp" line="75"/>
        <source>Processes</source>
        <translation>Procesos</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.cpp" line="75"/>
        <source>Uninstaller</source>
        <translation>Desinstalador</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.cpp" line="75"/>
        <source>Resources</source>
        <translation>Recursos</translation>
    </message>
</context>
<context>
    <name>StartupApp</name>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app.ui" line="128"/>
        <source>Edit App</source>
        <translation>Editar aplicación</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app.ui" line="150"/>
        <source>Delete App</source>
        <translation>Eliminar aplicación</translation>
    </message>
</context>
<context>
    <name>StartupAppEdit</name>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="20"/>
        <source>Startup App</source>
        <translation>Aplicación de inicio</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="74"/>
        <source>Save</source>
        <translation>Guardar</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="44"/>
        <source>Fields cannot be left blank. </source>
        <translation>Los campos no se pueden dejar en blanco. </translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="58"/>
        <source>App Comment</source>
        <translation>Comentario de la aplicación</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="51"/>
        <source>App Name</source>
        <translation>Nombre de la aplicación</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="97"/>
        <source>Command</source>
        <translation>Órden</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="87"/>
        <source>Application</source>
        <translation>Aplicación</translation>
    </message>
</context>
<context>
    <name>StartupAppsPage</name>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_apps_page.ui" line="201"/>
        <source>Not Found Startup Apps</source>
        <translation>Aplicaciones de inicio no encontradas</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_apps_page.ui" line="14"/>
        <source>Startup Apps</source>
        <translation>Aplicaciones de inicio</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_apps_page.ui" line="101"/>
        <source>Add Startup App</source>
        <translation>Añadir aplicación de inicio</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_apps_page.cpp" line="89"/>
        <source>Startup Applications (%1)</source>
        <translation>Aplicaciones de inicio (%1)</translation>
    </message>
</context>
<context>
    <name>SystemCleanerPage</name>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="14"/>
        <source>System Cleaner</source>
        <translation>Limpiador del Sistema</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="63"/>
        <source>Crash Reports</source>
        <translation>Informes de fallos</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="177"/>
        <source>Application Logs</source>
        <translation>Registros de aplicaciones</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="215"/>
        <source>Application Caches</source>
        <translation>Cachés de aplicaciones</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="363"/>
        <source>Trash</source>
        <translation>Papelera</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="401"/>
        <source>Package Caches</source>
        <translation>Cachés de paquetes</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="521"/>
        <source> Back</source>
        <translation> Volver</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.cpp" line="32"/>
        <source>File Name</source>
        <translation>Nombre del archivo</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.cpp" line="32"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.cpp" line="285"/>
        <source>%1 size files cleaned.</source>
        <translation>%1 del tamaño de los archivos limpiado.</translation>
    </message>
</context>
<context>
    <name>UninstallerPage</name>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstallerpage.ui" line="14"/>
        <source>Uninstaller</source>
        <translation>Desinstalador</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstallerpage.ui" line="90"/>
        <source>Search...</source>
        <translation>Buscar...</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstallerpage.ui" line="192"/>
        <source>Not Found Installed Packages</source>
        <translation>Paquetes instalados no encontrados</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstallerpage.ui" line="140"/>
        <source>Uninstall Selected</source>
        <translation>Desinstalar seleccionados</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstaller_page.cpp" line="67"/>
        <source>System Installed Packages (%1)</source>
        <translation>Paquetes instalados del Sistema (%1)</translation>
    </message>
</context>
<context>
    <name>UnitySettings</name>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="65"/>
        <source>Applications</source>
        <translation>Aplicaciones</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="108"/>
        <source>Show &quot;Recently Used&quot; applications</source>
        <translation>Mostrar &quot;aplicaciones&quot; usadas recientemente</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="134"/>
        <source>Enable search of your files</source>
        <translation>Habilitar la búsqueda de archivos</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="160"/>
        <source>Show &quot;More Suggestions&quot;</source>
        <translation type="unfinished">Mostrar &quot;más sugerencias&quot;</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="186"/>
        <source>Search</source>
        <translation>Buscar</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="196"/>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="683"/>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="229"/>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="660"/>
        <source>Transparency Level</source>
        <translation>Nivel de transparencia</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="280"/>
        <source>Behaviour</source>
        <translation>Comportamiento</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="323"/>
        <source>Auto Hide</source>
        <translation>Ocultar automáticamente</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="339"/>
        <source>Left Side</source>
        <translation>Lado izquierdo</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="380"/>
        <source>Minimize applications with clicking</source>
        <translation>Minimizar aplicaciones al clicar</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="396"/>
        <source>Top-Left Corner</source>
        <translation>Esquina superior izquierda</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="412"/>
        <source>Reveal Sensitivity</source>
        <translation>Revelar sensibilidad</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="438"/>
        <source>Reveal Location</source>
        <translation>Revelar localización</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="464"/>
        <source>Launcher</source>
        <translation>Lanzador</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="474"/>
        <source>Appearance</source>
        <translation>Apariencia</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="507"/>
        <source>Left</source>
        <translation>Izquierda</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="526"/>
        <source>Bottom</source>
        <translation>Abajo</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="542"/>
        <source>Visibility</source>
        <translation>Visibilidad</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="558"/>
        <source>Primary Desktop</source>
        <translation>Escritorio primario</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="612"/>
        <source>Icon size</source>
        <translation>Tamaño del ícono</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="628"/>
        <source>All Desktops</source>
        <translation>Todos los escritorios</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="644"/>
        <source>Position</source>
        <translation>Posición</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="726"/>
        <source>Search online sources</source>
        <translation>Buscar fuentes en línea</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="752"/>
        <source>Background Blur</source>
        <translation>Desenfoque de fondo</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="778"/>
        <source>Panel</source>
        <translation>Panel</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="801"/>
        <source>Indicators</source>
        <translation>Indicadores</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="840"/>
        <source>Date</source>
        <translation>Fecha</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="862"/>
        <source>Calendar</source>
        <translation>Calendario</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="875"/>
        <source>Date &amp; Time</source>
        <translation>Fecha &amp; hora</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="888"/>
        <source>24-Hour Time</source>
        <translation>24 horas</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="910"/>
        <source>Weekday</source>
        <translation>Día laboral</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="923"/>
        <source>Include</source>
        <translation>Incluir</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="945"/>
        <source>Seconds</source>
        <translation>Segundos</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="958"/>
        <source>Volume</source>
        <translation>Volúmen</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="971"/>
        <source>Show my name</source>
        <translation>Mostrar mi nombre</translation>
    </message>
</context>
<context>
    <name>WindowManagerSettings</name>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="90"/>
        <source>General</source>
        <translation>General</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="100"/>
        <source>Titlebar Actions</source>
        <translation>Acciones de la barra de titulo</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="155"/>
        <source>Right click</source>
        <translation>Botón derecho del raton</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="168"/>
        <source>Double click</source>
        <translation>Doble clic</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="181"/>
        <source>Middle click</source>
        <translation>Botón central del ratón</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="257"/>
        <source>Additional</source>
        <translation>Adicional</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="267"/>
        <source>Workspace Settings</source>
        <translation>Ajustes del espacio de trabajo</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="310"/>
        <source>Vertical workspaces</source>
        <translation>Espacios de trabajo verticales</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="333"/>
        <source>Workspace switcher</source>
        <translation>Interruptor de espacio de trabajo</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="356"/>
        <source>Horizontal workspaces</source>
        <translation>Espacios de trabajo horizontales</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="379"/>
        <source>Focus Behaviour</source>
        <translation>Comportamiento de enfoque</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="409"/>
        <source>Focus mode</source>
        <translation>Modo de enfoque</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="460"/>
        <source>Raise on click</source>
        <translation>Levantar al clicar</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="483"/>
        <source>Hardware Acceleration</source>
        <translation>Aceleración de hardware</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="538"/>
        <source>Text quality</source>
        <translation>Calidad del texto</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="66"/>
        <source>Fast</source>
        <translation>Rápido</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="66"/>
        <source>Good</source>
        <translation>Bueno</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="66"/>
        <source>Best</source>
        <translation>Mejor</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="68"/>
        <source>Click</source>
        <translation>Clic</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="68"/>
        <source>Sloppy</source>
        <translation>Sloppy</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="68"/>
        <source>Mouse</source>
        <translation>Ratón</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="80"/>
        <source>Toggle Shade</source>
        <translation>Alternar sombra</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="80"/>
        <source>Maximize</source>
        <translation>Maximizar</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="80"/>
        <source>Maximize Horizontally</source>
        <translation>Maximizar horizontalmente</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="81"/>
        <source>Maximize Vertically</source>
        <translation>Maximizar verticalmente</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="81"/>
        <source>Minimize</source>
        <translation>Minimizar</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="82"/>
        <source>None</source>
        <translation>Ninguno</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="82"/>
        <source>Lower</source>
        <translation>Abajo</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="82"/>
        <source>Menu</source>
        <translation>Menú</translation>
    </message>
</context>
</TS>
