<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="zh_CN">
<context>
    <name>APTSourceEdit</name>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_edit.ui" line="14"/>
        <source>APT Repository Edit</source>
        <translation type="finished">APT源编辑</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_edit.ui" line="38"/>
        <source>APT Repository</source>
        <translation type="finished">APT源</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_edit.ui" line="48"/>
        <source>Components</source>
        <translation type="finished">组件</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_edit.ui" line="55"/>
        <source>Options</source>
        <translation type="finished">选项</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_edit.ui" line="71"/>
        <source>Cancel</source>
        <translation type="finished">取消</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_edit.ui" line="87"/>
        <source>Fields cannot be left blank. </source>
        <translation type="finished">字段不能留空 </translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_edit.ui" line="94"/>
        <source>URI</source>
        <translation type="finished">URI</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_edit.ui" line="110"/>
        <source>Save</source>
        <translation type="finished">保存</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_edit.ui" line="133"/>
        <source>Distribution</source>
        <translation type="finished">发行版</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_edit.ui" line="152"/>
        <source>Source</source>
        <translation type="finished">源</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_edit.ui" line="177"/>
        <source>Binary</source>
        <translation type="finished">二进制</translation>
    </message>
</context>
<context>
    <name>APTSourceManagerPage</name>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.ui" line="188"/>
        <source>Search...</source>
        <translation type="finished">搜索...</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.ui" line="226"/>
        <source>Edit</source>
        <translation type="finished">编辑</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.ui" line="14"/>
        <source>APT Repository Manager</source>
        <translation type="finished">APT源管理</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.ui" line="125"/>
        <source>Not Found APT Repositories</source>
        <translation type="finished">未发现APT源</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.ui" line="269"/>
        <source>Delete</source>
        <translation type="finished">删除</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.ui" line="308"/>
        <source>Enable Source</source>
        <translation type="finished">使用源</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.ui" line="338"/>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.cpp" line="86"/>
        <source>Add Repository</source>
        <translation type="finished">添加源</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.ui" line="371"/>
        <source>Cancel</source>
        <translation type="finished">取消</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.ui" line="419"/>
        <source>Select to delete or edit.</source>
        <translation type="finished">选中即可删除或编辑.</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.cpp" line="25"/>
        <source>example %1</source>
        <translation type="finished">例如 %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.cpp" line="59"/>
        <source>APT Repositories (%1)</source>
        <translation type="finished">APT源(%1)</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.cpp" line="66"/>
        <source>Save</source>
        <translation type="finished">保存</translation>
    </message>
</context>
<context>
    <name>APTSourceRepositoryItem</name>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_repository_item.cpp" line="34"/>
        <source>%1 (Source Code)</source>
        <translation type="finished">%1 (源代码)</translation>
    </message>
</context>
<context>
    <name>App</name>
    <message>
        <location filename="../stacer/app.ui" line="101"/>
        <source>Dashboard</source>
        <translation>仪表盘</translation>
    </message>
    <message>
        <location filename="../stacer/app.ui" line="135"/>
        <source>Startup Apps</source>
        <translation type="finished">开机启动程序</translation>
    </message>
    <message>
        <location filename="../stacer/app.ui" line="163"/>
        <source>System Cleaner</source>
        <translation>系统清理</translation>
    </message>
    <message>
        <location filename="../stacer/app.ui" line="306"/>
        <source>APT Repository Manager</source>
        <translation type="finished">APT源管理</translation>
    </message>
    <message>
        <location filename="../stacer/app.ui" line="250"/>
        <source>Uninstaller</source>
        <translation>程序卸载</translation>
    </message>
    <message>
        <location filename="../stacer/app.ui" line="278"/>
        <source>Resources</source>
        <translation>系统资源</translation>
    </message>
    <message>
        <location filename="../stacer/app.ui" line="222"/>
        <source>Processes</source>
        <translation>进程</translation>
    </message>
    <message>
        <location filename="../stacer/app.ui" line="194"/>
        <source>Services</source>
        <translation type="finished">服务</translation>
    </message>
    <message>
        <location filename="../stacer/app.ui" line="334"/>
        <source>Gnome Settings</source>
        <translation type="finished">Gnome设置</translation>
    </message>
    <message>
        <location filename="../stacer/app.ui" line="362"/>
        <source>Settings</source>
        <translation>设置</translation>
    </message>
    <message>
        <location filename="../stacer/app.ui" line="403"/>
        <source>Feedback</source>
        <translation type="finished">反馈</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="111"/>
        <source>Quit</source>
        <translation type="finished">退出</translation>
    </message>
</context>
<context>
    <name>AppearanceSettings</name>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="44"/>
        <source>Screen Applications</source>
        <translation type="finished">屏幕程序</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="74"/>
        <source>Screen Reader</source>
        <translation type="finished">屏幕朗读</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="100"/>
        <source>Screen Keyboard</source>
        <translation type="finished">屏幕键盘</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="136"/>
        <source>Background Image Mode</source>
        <translation type="finished">背景图片模式</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="166"/>
        <source>Desktop Mode</source>
        <translation type="finished">桌面模式</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="204"/>
        <source>Login Mode</source>
        <translation type="finished">登录模式</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="252"/>
        <source>Icons</source>
        <translation type="finished">图标</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="282"/>
        <source>Home Icon</source>
        <translation type="finished">用户主图标</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="308"/>
        <source>Trash Icon</source>
        <translation type="finished">回收站图标</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="321"/>
        <source>Mounted Volumes Icon</source>
        <translation type="finished">已挂载卷图标</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="347"/>
        <source>Show Desktop Icons</source>
        <translation type="finished">显示桌面图标</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="373"/>
        <source>Network Icon</source>
        <translation type="finished">网络图标</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.cpp" line="71"/>
        <source>None</source>
        <translation type="finished">无</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.cpp" line="71"/>
        <source>Wallpaper</source>
        <translation type="finished">壁纸</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.cpp" line="71"/>
        <source>Centered</source>
        <translation type="finished">居中</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.cpp" line="72"/>
        <source>Scaled</source>
        <translation type="finished">按比例缩放</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.cpp" line="72"/>
        <source>Stretched</source>
        <translation type="finished">拉伸</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.cpp" line="72"/>
        <source>Zoom</source>
        <translation type="finished">缩放</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.cpp" line="72"/>
        <source>Spanned</source>
        <translation type="finished">贯穿</translation>
    </message>
</context>
<context>
    <name>DashboardPage</name>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.ui" line="20"/>
        <source>Dashboard</source>
        <translation type="finished">仪表盘</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.ui" line="156"/>
        <source>SYSTEM INFO</source>
        <translation>系统信息</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.ui" line="230"/>
        <source>There are update currently available.</source>
        <translation>当前有可用更新</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.ui" line="246"/>
        <source>Download</source>
        <translation>下载</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="14"/>
        <source>CPU</source>
        <translation>CPU</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="15"/>
        <source>MEMORY</source>
        <translation>内存</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="16"/>
        <source>DISK</source>
        <translation>磁盘</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="17"/>
        <source>DOWNLOAD</source>
        <translation>下载</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="18"/>
        <source>UPLOAD</source>
        <translation>上传</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="111"/>
        <source>Hostname: %1</source>
        <translation>主机名: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="112"/>
        <source>Platform: %1</source>
        <translation>平台: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="113"/>
        <source>Distribution: %1</source>
        <translation>发行版: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="114"/>
        <source>Kernel Release: %1</source>
        <translation>内核版本: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="115"/>
        <source>CPU Model: %1</source>
        <translation>CPU型号: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="117"/>
        <source>CPU Speed: %1</source>
        <translation>CPU频率: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="116"/>
        <source>CPU Core: %1</source>
        <translation>CPU内核数: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="133"/>
        <source>High CPU Usage</source>
        <translation type="finished">CPU负载高</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="134"/>
        <source>The amount of CPU used is over %1%.</source>
        <translation type="finished">CPU使用量已过%1%。</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="162"/>
        <source>High Memory Usage</source>
        <translation type="finished">内存负载高</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="163"/>
        <source>The amount of memory used is over %1%.</source>
        <translation type="finished">内存使用量已过%1%。</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="202"/>
        <source>High Disk Usage</source>
        <translation type="finished">磁盘负载高</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="203"/>
        <source>The amount of disk used is over %1%.</source>
        <translation type="finished">磁盘使用量已过%1%。</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="241"/>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="245"/>
        <source>Total: %1</source>
        <translation>总计: %1</translation>
    </message>
</context>
<context>
    <name>Feedback</name>
    <message>
        <location filename="../stacer/feedback.ui" line="14"/>
        <source>Feedback</source>
        <translation type="finished">反馈</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.ui" line="38"/>
        <source>Name</source>
        <translation type="finished">姓名</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.ui" line="45"/>
        <source>Email Address</source>
        <translation type="finished">邮件地址</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.ui" line="68"/>
        <source>Send</source>
        <translation type="finished">发送</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.ui" line="94"/>
        <source>Message</source>
        <translation type="finished">正文</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.ui" line="104"/>
        <source>Send a Feedback</source>
        <translation type="finished">发送反馈</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.cpp" line="46"/>
        <source>Email address is not valid !</source>
        <translation type="finished">邮件地址不正确!</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.cpp" line="51"/>
        <source>Your message must be at least 25 characters !</source>
        <translation type="finished">正文不得少于25个字符。</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.cpp" line="61"/>
        <source>Sending..</source>
        <translation type="finished">正在发送…</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.cpp" line="79"/>
        <source>&lt;font color=&apos;#2ecc71&apos;&gt;Your Feedback has been successfully sended.&lt;/font&gt;</source>
        <translation type="finished">&lt;font color=&apos;#2ecc71&apos;&gt;反馈发送成功。&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.cpp" line="81"/>
        <location filename="../stacer/feedback.cpp" line="86"/>
        <source>Something went wrong, try again !</source>
        <translation type="finished">出错，请重试！</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.cpp" line="89"/>
        <source>Save</source>
        <translation type="finished">保存</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.cpp" line="94"/>
        <source>Fields cannot be left blank !</source>
        <translation type="finished">此处不能留空！</translation>
    </message>
</context>
<context>
    <name>GnomeSettingsPage</name>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/gnome_settings_page.ui" line="14"/>
        <source>Gnome Settings</source>
        <translation type="finished">Gnome设置</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/gnome_settings_page.ui" line="49"/>
        <source>Unity Settings</source>
        <translation type="finished">Unity设置</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/gnome_settings_page.ui" line="81"/>
        <source>Window Manager</source>
        <translation type="finished">窗口管理器</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/gnome_settings_page.ui" line="110"/>
        <source>Appearance</source>
        <translation type="finished">屏幕外观</translation>
    </message>
</context>
<context>
    <name>ProcessesPage</name>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.ui" line="14"/>
        <location filename="../stacer/Pages/Processes/processes_page.ui" line="55"/>
        <source>Processes</source>
        <translation>进程</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.ui" line="71"/>
        <source>All Processes</source>
        <translation>全部进程</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.ui" line="96"/>
        <source>Search...</source>
        <translation>搜索…</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.ui" line="217"/>
        <source>End Process</source>
        <translation>结束进程</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="27"/>
        <source>User</source>
        <translation>用户</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="26"/>
        <source>Resident Memory</source>
        <translation>常驻内存</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="26"/>
        <source>%Memory</source>
        <translation>%内存</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="26"/>
        <source>Virtual Memory</source>
        <translation>虚拟内存</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="27"/>
        <source>Start Time</source>
        <translation>开始时间</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="27"/>
        <source>State</source>
        <translation>状态</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="27"/>
        <source>Group</source>
        <translation>群组</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="28"/>
        <source>Nice</source>
        <translation>优先值</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="28"/>
        <source>CPU Time</source>
        <translation>CPU时间</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="28"/>
        <source>Session</source>
        <translation>会话</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="28"/>
        <source>Process</source>
        <translation>进程</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="119"/>
        <source>Processes (%1)</source>
        <translation>进程 (%1)</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="210"/>
        <source>Refresh (%1)</source>
        <translation>刷新 (%1)</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../stacer/Managers/setting_manager.cpp" line="61"/>
        <source>Dashboard</source>
        <translation type="finished">仪表盘</translation>
    </message>
</context>
<context>
    <name>ResourcesPage</name>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="14"/>
        <source>History of CPU</source>
        <translation type="finished">CPU历史</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="15"/>
        <source>History of CPU Load Averages</source>
        <translation type="finished">CPU平均负载历史记录</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="16"/>
        <source>History of Disk Read Write</source>
        <translation type="finished">磁盘读写历史</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="17"/>
        <source>History of Memory</source>
        <translation type="finished">内存历史</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="18"/>
        <source>History of Network</source>
        <translation type="finished">网络历史</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="75"/>
        <source>Read: %1/s Total: %2</source>
        <translation type="finished">读取: %1/s 总计: %2</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="81"/>
        <source>Write: %1/s Total: %2</source>
        <translation type="finished">写入: %1/s 总计: %2</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="118"/>
        <source>%1 Minute Average: %2</source>
        <translation type="finished">%1 分钟平均值: %2</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="164"/>
        <source>Download: %1/s Total: %2</source>
        <translation type="finished">下载: %1/s 总计: %2</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="169"/>
        <source>Upload: %1/s  Total: %2</source>
        <translation type="finished">上传: %1/s 总计: %2</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="213"/>
        <source>Swap: %1 (%2%) %3</source>
        <translation type="finished">交换分区: %1 (%2%) %3</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="222"/>
        <source>Memory: %1 (%2%) %3</source>
        <translation type="finished">内存: %1 (%2%) %3</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.ui" line="14"/>
        <source>Resources</source>
        <translation type="finished">系统资源</translation>
    </message>
</context>
<context>
    <name>ServicesPage</name>
    <message>
        <location filename="../stacer/Pages/Services/services_page.ui" line="14"/>
        <source>Services</source>
        <translation type="finished">服务</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.ui" line="137"/>
        <source>Startup at boot ?</source>
        <translation>设置为开机启动吗?</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.ui" line="190"/>
        <source>Running Now ?</source>
        <translation>现在运行吗?</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.ui" line="244"/>
        <source>Not Found System Service</source>
        <translation>未找到系统服务</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.cpp" line="27"/>
        <source>Running Status</source>
        <translation type="finished">运行状态</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.cpp" line="27"/>
        <source>Running</source>
        <translation type="finished">正在运行</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.cpp" line="27"/>
        <source>Not Running</source>
        <translation type="finished">未在运行</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.cpp" line="28"/>
        <source>Startup Status</source>
        <translation type="finished">启动状态</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.cpp" line="28"/>
        <source>Enabled</source>
        <translation type="finished">启用</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.cpp" line="28"/>
        <source>Disabled</source>
        <translation type="finished">禁止</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.cpp" line="75"/>
        <source>System Services (%1)</source>
        <translation>系统服务 (%1)</translation>
    </message>
</context>
<context>
    <name>SettingsPage</name>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="20"/>
        <source>Settings</source>
        <translation type="finished">设置</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="110"/>
        <source>Memory Percent</source>
        <translation type="finished">内存占比</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="204"/>
        <source>Disk Percent</source>
        <translation type="finished">磁盘占比</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="233"/>
        <source>Disks</source>
        <translation type="finished">磁盘分区</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="246"/>
        <source>Language</source>
        <translation>语言</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="259"/>
        <source>Autostart Stacer</source>
        <translation type="finished">Stacer自启动</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="317"/>
        <source>Alert messages (Show a warning after the specified percentage)</source>
        <translation type="finished">提醒信息（在超过指定百分比后显示警告）</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="422"/>
        <source>Start Page</source>
        <translation type="finished">开始页面</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="301"/>
        <source>CPU Percent</source>
        <translation type="finished">CPU占比</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="324"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Created by &lt;a href=&quot;https://github.com/oguzhaninan&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#007af4;&quot;&gt;Oğuzhan İNAN&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="finished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;由&lt;a href=&quot;https://github.com/oguzhaninan&quot;&gt;&lt;创建 span style=&quot; text-decoration: underline; color:#007af4;&quot;&gt;Oğuzhan İNAN&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="355"/>
        <source>Donate</source>
        <translation type="finished">捐赠</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="97"/>
        <source>Theme</source>
        <translation>主题</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.cpp" line="74"/>
        <source>Dashboard</source>
        <translation type="finished">仪表盘</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.cpp" line="74"/>
        <source>Startup Apps</source>
        <translation type="finished">开机启动程序</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.cpp" line="74"/>
        <source>System Cleaner</source>
        <translation type="finished">系统清理</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.cpp" line="75"/>
        <source>Services</source>
        <translation type="finished">服务</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.cpp" line="75"/>
        <source>Processes</source>
        <translation type="finished">进程</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.cpp" line="75"/>
        <source>Uninstaller</source>
        <translation type="finished">卸载程序</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.cpp" line="75"/>
        <source>Resources</source>
        <translation type="finished">系统资源</translation>
    </message>
</context>
<context>
    <name>StartupApp</name>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app.ui" line="128"/>
        <source>Edit App</source>
        <translation type="finished">编辑程序</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app.ui" line="150"/>
        <source>Delete App</source>
        <translation type="finished">删除程序</translation>
    </message>
</context>
<context>
    <name>StartupAppEdit</name>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="20"/>
        <source>Startup App</source>
        <translation>开机启动程序</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="74"/>
        <source>Save</source>
        <translation>保存</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="44"/>
        <source>Fields cannot be left blank. </source>
        <translation>字段不能留空。</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="58"/>
        <source>App Comment</source>
        <translation>程序备注</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="51"/>
        <source>App Name</source>
        <translation>程序名称</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="97"/>
        <source>Command</source>
        <translation>命令</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="87"/>
        <source>Application</source>
        <translation>程序</translation>
    </message>
</context>
<context>
    <name>StartupAppsPage</name>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_apps_page.ui" line="201"/>
        <source>Not Found Startup Apps</source>
        <translation>未发现开机启动程序</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_apps_page.ui" line="14"/>
        <source>Startup Apps</source>
        <translation type="finished">开机启动程序</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_apps_page.ui" line="101"/>
        <source>Add Startup App</source>
        <translation>添加开机启动程序</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_apps_page.cpp" line="89"/>
        <source>Startup Applications (%1)</source>
        <translation type="finished">开机启动程序(%1)</translation>
    </message>
</context>
<context>
    <name>SystemCleanerPage</name>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="14"/>
        <source>System Cleaner</source>
        <translation type="finished">系统清理</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="63"/>
        <source>Crash Reports</source>
        <translation>崩溃报告</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="177"/>
        <source>Application Logs</source>
        <translation>程序日志</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="215"/>
        <source>Application Caches</source>
        <translation>应用缓存</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="363"/>
        <source>Trash</source>
        <translation>回收站</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="401"/>
        <source>Package Caches</source>
        <translation>包缓存</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="521"/>
        <source> Back</source>
        <translation> 返回</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.cpp" line="32"/>
        <source>File Name</source>
        <translation>文件名</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.cpp" line="32"/>
        <source>Size</source>
        <translation>大小</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.cpp" line="285"/>
        <source>%1 size files cleaned.</source>
        <translation>已经清理文件%1。</translation>
    </message>
</context>
<context>
    <name>UninstallerPage</name>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstallerpage.ui" line="14"/>
        <source>Uninstaller</source>
        <translation type="finished">卸载程序</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstallerpage.ui" line="90"/>
        <source>Search...</source>
        <translation>搜索…</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstallerpage.ui" line="192"/>
        <source>Not Found Installed Packages</source>
        <translation>未发现已安装过的包</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstallerpage.ui" line="140"/>
        <source>Uninstall Selected</source>
        <translation>卸载选中项</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstaller_page.cpp" line="67"/>
        <source>System Installed Packages (%1)</source>
        <translation>系统已安装了的包 (%1)</translation>
    </message>
</context>
<context>
    <name>UnitySettings</name>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="65"/>
        <source>Applications</source>
        <translation type="finished">程序</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="108"/>
        <source>Show &quot;Recently Used&quot; applications</source>
        <translation type="finished">显示&quot;近期使用&quot;程序</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="134"/>
        <source>Enable search of your files</source>
        <translation type="finished">启用文件搜索</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="160"/>
        <source>Show &quot;More Suggestions&quot;</source>
        <translation type="finished">显示&quot;更多建议&quot;</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="186"/>
        <source>Search</source>
        <translation type="finished">搜索</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="196"/>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="683"/>
        <source>General</source>
        <translation type="finished">常规</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="229"/>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="660"/>
        <source>Transparency Level</source>
        <translation type="finished">透明程度</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="280"/>
        <source>Behaviour</source>
        <translation type="finished">行为</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="323"/>
        <source>Auto Hide</source>
        <translation type="finished">自动隐藏</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="339"/>
        <source>Left Side</source>
        <translation type="finished">左侧</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="380"/>
        <source>Minimize applications with clicking</source>
        <translation type="finished">通过点击最小化程序</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="396"/>
        <source>Top-Left Corner</source>
        <translation type="finished">左上角</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="412"/>
        <source>Reveal Sensitivity</source>
        <translation type="finished">展示灵敏度</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="438"/>
        <source>Reveal Location</source>
        <translation type="finished">展示区域</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="464"/>
        <source>Launcher</source>
        <translation type="finished">启动器</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="474"/>
        <source>Appearance</source>
        <translation type="finished">外观</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="507"/>
        <source>Left</source>
        <translation type="finished">左侧</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="526"/>
        <source>Bottom</source>
        <translation type="finished">底部</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="542"/>
        <source>Visibility</source>
        <translation type="finished">可见</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="558"/>
        <source>Primary Desktop</source>
        <translation type="finished">主桌面</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="612"/>
        <source>Icon size</source>
        <translation type="finished">图标尺寸</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="628"/>
        <source>All Desktops</source>
        <translation type="finished">所有桌面</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="644"/>
        <source>Position</source>
        <translation type="finished">位置</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="726"/>
        <source>Search online sources</source>
        <translation type="finished">搜索网络源</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="752"/>
        <source>Background Blur</source>
        <translation type="finished">背景模糊</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="778"/>
        <source>Panel</source>
        <translation type="finished">面板</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="801"/>
        <source>Indicators</source>
        <translation type="finished">系统托盘指示器</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="840"/>
        <source>Date</source>
        <translation type="finished">日期</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="862"/>
        <source>Calendar</source>
        <translation type="finished">日历</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="875"/>
        <source>Date &amp; Time</source>
        <translation type="finished">日期 &amp; 时间</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="888"/>
        <source>24-Hour Time</source>
        <translation type="finished">24时间制</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="910"/>
        <source>Weekday</source>
        <translation type="finished">工作日</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="923"/>
        <source>Include</source>
        <translation type="finished">包括</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="945"/>
        <source>Seconds</source>
        <translation type="finished">秒</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="958"/>
        <source>Volume</source>
        <translation type="finished">卷</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="971"/>
        <source>Show my name</source>
        <translation type="finished">显示用户名</translation>
    </message>
</context>
<context>
    <name>WindowManagerSettings</name>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="90"/>
        <source>General</source>
        <translation type="finished">常规</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="100"/>
        <source>Titlebar Actions</source>
        <translation type="finished">标题栏动作</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="155"/>
        <source>Right click</source>
        <translation type="finished">右键点击</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="168"/>
        <source>Double click</source>
        <translation type="finished">左键双击</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="181"/>
        <source>Middle click</source>
        <translation type="finished">中键点击</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="257"/>
        <source>Additional</source>
        <translation type="finished">附加</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="267"/>
        <source>Workspace Settings</source>
        <translation type="finished">工作区设置</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="310"/>
        <source>Vertical workspaces</source>
        <translation type="finished">工作区垂直排列</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="333"/>
        <source>Workspace switcher</source>
        <translation type="finished">工作区切换器</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="356"/>
        <source>Horizontal workspaces</source>
        <translation type="finished">工作区水平排列</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="379"/>
        <source>Focus Behaviour</source>
        <translation type="finished">鼠标焦点行为</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="409"/>
        <source>Focus mode</source>
        <translation type="finished">焦点模式</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="460"/>
        <source>Raise on click</source>
        <translation type="finished">点击则提升到最上层</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="483"/>
        <source>Hardware Acceleration</source>
        <translation type="finished">硬件加速</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="538"/>
        <source>Text quality</source>
        <translation type="finished">文本质量</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="66"/>
        <source>Fast</source>
        <translation type="finished">快速</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="66"/>
        <source>Good</source>
        <translation type="finished">好</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="66"/>
        <source>Best</source>
        <translation type="finished">最好</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="68"/>
        <source>Click</source>
        <translation type="finished">点击</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="68"/>
        <source>Sloppy</source>
        <translation type="finished">滑过</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="68"/>
        <source>Mouse</source>
        <translation type="finished">鼠标</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="80"/>
        <source>Toggle Shade</source>
        <translation type="finished">切换形状</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="80"/>
        <source>Maximize</source>
        <translation type="finished">最大化</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="80"/>
        <source>Maximize Horizontally</source>
        <translation type="finished">水平最大化</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="81"/>
        <source>Maximize Vertically</source>
        <translation type="finished">垂直最大化</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="81"/>
        <source>Minimize</source>
        <translation type="finished">最小化</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="82"/>
        <source>None</source>
        <translation type="finished">无</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="82"/>
        <source>Lower</source>
        <translation type="finished">更低</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="82"/>
        <source>Menu</source>
        <translation type="finished">菜单</translation>
    </message>
</context>
</TS>
