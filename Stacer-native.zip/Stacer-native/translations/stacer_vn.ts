<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="vi_VN">
<context>
    <name>App</name>
    <message>
        <location filename="../stacer/app.cpp" line="80"/>
        <source>Dashboard</source>
        <translation>Bảng Điều Khiển</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="85"/>
        <source>System Cleaner</source>
        <translation>Làm Sạch Hệ Thống</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="90"/>
        <source>System Startup Apps</source>
        <translation>Ứng Dụng Khởi Động Cùng Hệ Thống</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="95"/>
        <source>System Services</source>
        <translation>Dịch Vụ Hệ Thống</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="100"/>
        <source>Uninstaller</source>
        <translation>Gỡ Cài Đặt</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="105"/>
        <source>Resources</source>
        <translation>Biểu Đồ Tài Nguyên</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="110"/>
        <source>Processes</source>
        <translation>Tiến Trình</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="115"/>
        <source>Settings</source>
        <translation>Cài Đặt</translation>
    </message>
</context>
<context>
    <name>DashboardPage</name>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.ui" line="153"/>
        <source>SYSTEM INFO</source>
        <translation>Thông Tin Hệ Thống</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.ui" line="240"/>
        <source>There are update currently available.</source>
        <translation>Có Cập Nhật Mới</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.ui" line="253"/>
        <source>Download</source>
        <translation>Tải Xuống</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="18"/>
        <source>CPU</source>
        <translation>CPU</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="19"/>
        <source>MEMORY</source>
        <translation>RAM</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="20"/>
        <source>DISK</source>
        <translation>Ổ Đĩa</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="21"/>
        <source>DOWNLOAD</source>
        <translation>Tải Xuống</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="22"/>
        <source>UPLOAD</source>
        <translation>Tải Lên</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="107"/>
        <source>Hostname: %1</source>
        <translation>Tên Máy: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="108"/>
        <source>Platform: %1</source>
        <translation>Nền Tảng: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="109"/>
        <source>Distribution: %1</source>
        <translation>Phiên Bản: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="110"/>
        <source>Kernel Release: %1</source>
        <translation>Phiên Bản Kernel: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="111"/>
        <source>CPU Model: %1</source>
        <translation>Model Của CPU: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="112"/>
        <source>CPU Speed: %1</source>
        <translation>Tốc Độ CPU: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="113"/>
        <source>CPU Core: %1</source>
        <translation>Nhân CPU:%1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="182"/>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="186"/>
        <source>Total: %1</source>
        <translation>Tổng: %1</translation>
    </message>
</context>
<context>
    <name>ProcessesPage</name>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.ui" line="55"/>
        <source>Processes</source>
        <translation>Tiến Trình</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.ui" line="68"/>
        <source>All Processes</source>
        <translation>Tất Cả Tiến Trình</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.ui" line="88"/>
        <source>Search...</source>
        <translation>Tìm Kiếm...</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.ui" line="206"/>
        <source>End Process</source>
        <translation>Kết Thúc Tiến Trình</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="35"/>
        <source>User</source>
        <translation>Người Dùng</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="35"/>
        <source>Resident MEMORY</source>
        <translation>RAM Sử Dụng</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="35"/>
        <source>%Memory</source>
        <translation>% RAM</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="35"/>
        <source>Virtual Memory</source>
        <translation>RAM Ảo </translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="36"/>
        <source>Start Time</source>
        <translation>Thời Gian Bắt Đầu</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="36"/>
        <source>State</source>
        <translation>Khu Vực</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="36"/>
        <source>Group</source>
        <translation>Nhóm</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="36"/>
        <source>Nice</source>
        <translation>Tốt</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="36"/>
        <source>CPU Time</source>
        <translation>Thời Gian CPC</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="37"/>
        <source>Session</source>
        <translation>Phiên Làm Việc</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="37"/>
        <source>Seat</source>
        <translation>Vị Trí</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="37"/>
        <source>Process</source>
        <translation>Tiến Trình</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="104"/>
        <source>Processes (%1)</source>
        <translation>Tiến Trình (%1)</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="198"/>
        <source>Refresh (%1)</source>
        <translation>Làm Mới (%1)</translation>
    </message>
</context>
<context>
    <name>ResourcesPage</name>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="26"/>
        <source>CPU History</source>
        <translation>Lịch Sử CPC</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="29"/>
        <source>Memory History</source>
        <translation>Lịch Sử RAM</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="32"/>
        <source>Network History</source>
        <translation>Kết Nối Internet</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="76"/>
        <source>Download %1/s Total: %2</source>
        <translation>Tải Xuống %1/s Tổng: %2</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="81"/>
        <source>Upload %1/s  Total: %2</source>
        <translation>Tải Lên %1 /s Tổng: %2</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="122"/>
        <source>Swap %1 (%2%) %3</source>
        <translation>SWAP %1 (%2%) %3</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="131"/>
        <source>Memory %1 (%2%) %3</source>
        <translation>RAM %1 (%2%) %3</translation>
    </message>
</context>
<context>
    <name>ServicesPage</name>
    <message>
        <location filename="../stacer/Pages/Services/services_page.ui" line="79"/>
        <source>System Services</source>
        <translation>Dịch Vụ Hệ Thống</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.ui" line="123"/>
        <source>Startup at boot ?</source>
        <translation>Khởi Động Cùng Hệ Thống ?</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.ui" line="176"/>
        <source>Running Now ?</source>
        <translation>Đang Chạy ?</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.ui" line="246"/>
        <source>Not Found System Service</source>
        <translation>Không Tìm Thấy Dịch Vụ Hệ Thống</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.cpp" line="50"/>
        <source>System Services (%1)</source>
        <translation>Dịch Vụ Hệ Thống (%1)</translation>
    </message>
</context>
<context>
    <name>SettingsPage</name>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="54"/>
        <source>Language</source>
        <translation>Ngôn Ngữ</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="71"/>
        <source>Theme</source>
        <translation>Giao Diện</translation>
    </message>
</context>
<context>
    <name>StartupApp</name>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app.cpp" line="23"/>
        <source>Delete</source>
        <translation>Xóa</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app.cpp" line="24"/>
        <source>Edit</source>
        <translation>Sửa</translation>
    </message>
</context>
<context>
    <name>StartupAppEdit</name>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="20"/>
        <source>Startup App</source>
        <translation>Ứng Dụng Khởi Động Cùng Hệ Thống</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="50"/>
        <source>Save</source>
        <translation>Lưu</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="60"/>
        <source>Fields cannot be left blank. </source>
        <translation>Trường Nhập Không Được Bỏ Trống.</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="67"/>
        <source>App Comment</source>
        <translation>Mô Tả Ứng Dụng</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="74"/>
        <source>App Name</source>
        <translation>Tên Ứng Dụng</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="81"/>
        <source>Command</source>
        <translation>Lệnh</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="88"/>
        <source>Application</source>
        <translation>Ứng Dụng</translation>
    </message>
</context>
<context>
    <name>StartupAppsPage</name>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_apps_page.ui" line="192"/>
        <source>Not Found Startup Apps</source>
        <translation>Không Tìm Thấy Ứng Dụng Khởi Động Cùng Hệ Thống</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_apps_page.ui" line="112"/>
        <source>System Startup Applications</source>
        <translation>Ứng Dụng Khởi Động Cùng Hệ Thống</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_apps_page.ui" line="95"/>
        <source>Add Startup App</source>
        <translation>Thêm Ứng Dụng</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_apps_page.cpp" line="79"/>
        <source>System Startup Applications (%1)</source>
        <translation>Ứng Dụng Khởi Động Cùng Hệ Thống (%1)</translation>
    </message>
</context>
<context>
    <name>SystemCleanerPage</name>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="63"/>
        <source>Crash Reports</source>
        <translation>Báo Cáo Lỗi</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="168"/>
        <source>Application Logs</source>
        <translation>Bản Ghi Ứng Dụng</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="206"/>
        <source>Application Caches</source>
        <translation>Bộ Nhớ Tạm Ứng Dụng</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="327"/>
        <source>Trash</source>
        <translation>Thùng Rác</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="365"/>
        <source>Package Caches</source>
        <translation>Bộ Nhớ Tạm Gói</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="473"/>
        <source> Back</source>
        <translation> Quay Lại</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.cpp" line="32"/>
        <source>File Name</source>
        <translation>Tên Tập Tin</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.cpp" line="32"/>
        <source>Size</source>
        <translation>Kích Cỡ</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.cpp" line="285"/>
        <source>%1 size files cleaned.</source>
        <translation>%1 Kích Cỡ Tập Tin Được Làm Sạch</translation>
    </message>
</context>
<context>
    <name>UninstallerPage</name>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstallerpage.ui" line="228"/>
        <source>System Installed Packages</source>
        <translation>Gói Hệ Thống Đã Cài Đặt</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstallerpage.ui" line="271"/>
        <source>Search...</source>
        <translation>Tìm Kiếm...</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstallerpage.ui" line="178"/>
        <source>Not Found Installed Packages</source>
        <translation>Không Tìm Thấy Gói</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstallerpage.ui" line="132"/>
        <source>Uninstall Selected</source>
        <translation>Gỡ Bỏ Gói Đã Chọn</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstaller_page.cpp" line="65"/>
        <source>System Installed Packages (%1)</source>
        <translation>Gói Hệ Thống Đã Cài Đặt (%1)</translation>
    </message>
</context>
</TS>
