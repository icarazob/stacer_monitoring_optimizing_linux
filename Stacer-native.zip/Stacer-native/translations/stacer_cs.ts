<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="de_DE">
<context>
    <name>APTSourceEdit</name>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_edit.ui" line="14"/>
        <source>APT Repository Edit</source>
        <translation>Upravit repozitář APT</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_edit.ui" line="38"/>
        <source>APT Repository</source>
        <translation>Repozitář APT</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_edit.ui" line="48"/>
        <source>Components</source>
        <translation>Komponenty</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_edit.ui" line="55"/>
        <source>Options</source>
        <translation>Parametry</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_edit.ui" line="71"/>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_edit.ui" line="87"/>
        <source>Fields cannot be left blank. </source>
        <translation>Musíte vyplnit všechna pole. </translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_edit.ui" line="94"/>
        <source>URI</source>
        <translation>URI</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_edit.ui" line="110"/>
        <source>Save</source>
        <translation>Uložit</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_edit.ui" line="133"/>
        <source>Distribution</source>
        <translation>Distribuce</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_edit.ui" line="152"/>
        <source>Source</source>
        <translation>Zdroje</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_edit.ui" line="177"/>
        <source>Binary</source>
        <translation>Binární</translation>
    </message>
</context>
<context>
    <name>APTSourceManagerPage</name>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.ui" line="188"/>
        <source>Search...</source>
        <translation>Hledat...</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.ui" line="226"/>
        <source>Edit</source>
        <translation>Upravit</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.ui" line="14"/>
        <source>APT Repository Manager</source>
        <translation>Správce repozitářů APT</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.ui" line="125"/>
        <source>Not Found APT Repositories</source>
        <translation>Nebyly nalezeny žádne repozitáře APT</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.ui" line="269"/>
        <source>Delete</source>
        <translation>Smazat</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.ui" line="308"/>
        <source>Enable Source</source>
        <translation>Povolit zdroje</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.ui" line="338"/>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.cpp" line="86"/>
        <source>Add Repository</source>
        <translation>Přidat repozitář</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.ui" line="371"/>
        <source>Cancel</source>
        <translation>Zrušit</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.ui" line="419"/>
        <source>Select to delete or edit.</source>
        <translation>Vybat pro smazání nebo úpravu</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.cpp" line="25"/>
        <source>example %1</source>
        <translation>příklad %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.cpp" line="59"/>
        <source>APT Repositories (%1)</source>
        <translation>Repozitáře APT (%1)</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_manager_page.cpp" line="66"/>
        <source>Save</source>
        <translation>Uložit</translation>
    </message>
</context>
<context>
    <name>APTSourceRepositoryItem</name>
    <message>
        <location filename="../stacer/Pages/AptSourceManager/apt_source_repository_item.cpp" line="34"/>
        <source>%1 (Source Code)</source>
        <translation>%1 (Zdroje)</translation>
    </message>
</context>
<context>
    <name>App</name>
    <message>
        <location filename="../stacer/app.ui" line="101"/>
        <source>Dashboard</source>
        <translation>Nástěnka</translation>
    </message>
    <message>
        <location filename="../stacer/app.ui" line="135"/>
        <source>Startup Apps</source>
        <translation>Automatické spuštění aplikací</translation>
    </message>
    <message>
        <location filename="../stacer/app.ui" line="163"/>
        <source>System Cleaner</source>
        <translation>Čistič systému</translation>
    </message>
    <message>
        <location filename="../stacer/app.ui" line="306"/>
        <source>APT Repository Manager</source>
        <translation>Správce repozitářů APT</translation>
    </message>
    <message>
        <location filename="../stacer/app.ui" line="250"/>
        <source>Uninstaller</source>
        <translation>Odinstalovávač</translation>
    </message>
    <message>
        <location filename="../stacer/app.ui" line="278"/>
        <source>Resources</source>
        <translation>Prostředky</translation>
    </message>
    <message>
        <location filename="../stacer/app.ui" line="222"/>
        <source>Processes</source>
        <translation>Procesy</translation>
    </message>
    <message>
        <location filename="../stacer/app.ui" line="194"/>
        <source>Services</source>
        <translation>Služby</translation>
    </message>
    <message>
        <location filename="../stacer/app.ui" line="334"/>
        <source>Gnome Settings</source>
        <translation>Nastavení Gnome</translation>
    </message>
    <message>
        <location filename="../stacer/app.ui" line="362"/>
        <source>Settings</source>
        <translation>Nastavení</translation>
    </message>
    <message>
        <location filename="../stacer/app.ui" line="403"/>
        <source>Feedback</source>
        <translation>Zpětná vazba</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="97"/>
        <location filename="../stacer/app.cpp" line="102"/>
        <location filename="../stacer/app.cpp" line="134"/>
        <source>Quit</source>
        <translation>Zavřít</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="99"/>
        <source>Continue</source>
        <translation>Pokračovat</translation>
    </message>
    <message>
        <location filename="../stacer/app.cpp" line="103"/>
        <source>Will the program continue to work in the system tray?</source>
        <translation>Má program pokračovat v práci na systémové liště?</translation>
    </message>
</context>
<context>
    <name>AppearanceSettings</name>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="44"/>
        <source>Screen Applications</source>
        <translation>Aplikace na obrazovce</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="74"/>
        <source>Screen Reader</source>
        <translation>Předčítač obrazovky</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="100"/>
        <source>Screen Keyboard</source>
        <translation>Klávesnice na obrazovce</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="136"/>
        <source>Background Image Mode</source>
        <translation>Režim tapety</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="166"/>
        <source>Desktop Mode</source>
        <translation>Režim plochy</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="204"/>
        <source>Login Mode</source>
        <translation>Režim přihlášení</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="252"/>
        <source>Icons</source>
        <translation>Ikony</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="282"/>
        <source>Home Icon</source>
        <translation>Ikona domů</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="308"/>
        <source>Trash Icon</source>
        <translation>Ikona koše</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="321"/>
        <source>Mounted Volumes Icon</source>
        <translation>Ikona připojených disků</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="347"/>
        <source>Show Desktop Icons</source>
        <translation>Zobrazit ikony na ploše</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.ui" line="373"/>
        <source>Network Icon</source>
        <translation>Ikona sítě</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.cpp" line="71"/>
        <source>None</source>
        <translation>Žádný</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.cpp" line="71"/>
        <source>Wallpaper</source>
        <translation>Pozadí</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.cpp" line="71"/>
        <source>Centered</source>
        <translation>Vycentrované</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.cpp" line="72"/>
        <source>Scaled</source>
        <translation>Škálované</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.cpp" line="72"/>
        <source>Stretched</source>
        <translation>Roztažené</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.cpp" line="72"/>
        <source>Zoom</source>
        <translation>Přiblížené</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/appearance_settings.cpp" line="72"/>
        <source>Spanned</source>
        <translation>Rozložené</translation>
    </message>
</context>
<context>
    <name>DashboardPage</name>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.ui" line="20"/>
        <source>Dashboard</source>
        <translation>Nástěnka</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.ui" line="156"/>
        <source>SYSTEM INFO</source>
        <translation>INFORMACE O SYSTÉMU</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.ui" line="230"/>
        <source>There are update currently available.</source>
        <translation>K disposici je aktualizace</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.ui" line="246"/>
        <source>Download</source>
        <translation>Stáhnout</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="14"/>
        <source>CPU</source>
        <translation>PROCESOR</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="111"/>
        <source>Hostname: %1</source>
        <translation>Jméno počítače: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="112"/>
        <source>Platform: %1</source>
        <translation>Systém: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="113"/>
        <source>Distribution: %1</source>
        <translation>Distribuce: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="114"/>
        <source>Kernel Release: %1</source>
        <translation>Verze jádra: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="115"/>
        <source>CPU Model: %1</source>
        <translation>Model procesoru: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="117"/>
        <source>CPU Speed: %1</source>
        <translation>Frekvence procesoru: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="116"/>
        <source>CPU Core: %1</source>
        <translation>Jádra procesoru: %1</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="15"/>
        <source>MEMORY</source>
        <translation>PAMĚŤ</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="16"/>
        <source>DISK</source>
        <translation>DISK</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="17"/>
        <source>DOWNLOAD</source>
        <translation>STAHOVÁNÍ</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="18"/>
        <source>UPLOAD</source>
        <translation>NAHRÁVÁNÍ</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="133"/>
        <source>High CPU Usage</source>
        <translation>Vysoké využití procesoru</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="134"/>
        <source>The amount of CPU used is over %1%.</source>
        <translation>Využití procesoru je vyšší než %1%.</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="162"/>
        <source>High Memory Usage</source>
        <translation>Vysoké využití paměti</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="163"/>
        <source>The amount of memory used is over %1%.</source>
        <translation>Využití paměti je vyšší než %1%.</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="206"/>
        <source>High Disk Usage</source>
        <translation>Vysoké využití disku</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="207"/>
        <source>The amount of disk used is over %1%.</source>
        <translation>Využití disku je vyšší než %1%.</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="245"/>
        <location filename="../stacer/Pages/Dashboard/dashboard_page.cpp" line="249"/>
        <source>Total: %1</source>
        <translation>Celkem: %1</translation>
    </message>
</context>
<context>
    <name>Feedback</name>
    <message>
        <location filename="../stacer/feedback.ui" line="14"/>
        <source>Feedback</source>
        <translation>Zpětná vazba</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.ui" line="38"/>
        <source>Name</source>
        <translation>Jméno</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.ui" line="45"/>
        <source>Email Address</source>
        <translation>Emailová adresa</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.ui" line="68"/>
        <source>Send</source>
        <translation>Odeslat</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.ui" line="94"/>
        <source>Message</source>
        <translation>Zpráva</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.ui" line="104"/>
        <source>Send a Feedback</source>
        <translation>Odeslat zpětnou vazbu</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.cpp" line="46"/>
        <source>Email address is not valid !</source>
        <translation>Emailová adresa je neplatná!</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.cpp" line="51"/>
        <source>Your message must be at least 25 characters !</source>
        <translation>Vaše zpráva musí být delší než 25 znaků!</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.cpp" line="61"/>
        <source>Sending..</source>
        <translation>Odesílání..</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.cpp" line="79"/>
        <source>&lt;font color=&apos;#2ecc71&apos;&gt;Your Feedback has been successfully sended.&lt;/font&gt;</source>
        <translation>&lt;font color=&apos;#2ecc71&apos;&gt;Vaše zpětná vazba byla úspěšně odeslána.&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.cpp" line="81"/>
        <location filename="../stacer/feedback.cpp" line="86"/>
        <source>Something went wrong, try again !</source>
        <translation>Něco se pokazilo, zkuste to znovu!</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.cpp" line="89"/>
        <source>Save</source>
        <translation>Uložit</translation>
    </message>
    <message>
        <location filename="../stacer/feedback.cpp" line="94"/>
        <source>Fields cannot be left blank !</source>
        <translation>Musíte vyplnit všechna pole!</translation>
    </message>
</context>
<context>
    <name>GnomeSettingsPage</name>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/gnome_settings_page.ui" line="14"/>
        <source>Gnome Settings</source>
        <translation>Nastavení Gnome</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/gnome_settings_page.ui" line="49"/>
        <source>Unity Settings</source>
        <translation>Nastavení Unity</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/gnome_settings_page.ui" line="81"/>
        <source>Window Manager</source>
        <translation>Správce oken</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/gnome_settings_page.ui" line="110"/>
        <source>Appearance</source>
        <translation>Vzhled</translation>
    </message>
</context>
<context>
    <name>ProcessesPage</name>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.ui" line="14"/>
        <location filename="../stacer/Pages/Processes/processes_page.ui" line="55"/>
        <source>Processes</source>
        <translation>Procesy</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.ui" line="71"/>
        <source>All Processes</source>
        <translation>Všechny procesy</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.ui" line="96"/>
        <source>Search...</source>
        <translation>Hledat...</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.ui" line="217"/>
        <source>End Process</source>
        <translation>Ukončit proces</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="27"/>
        <source>User</source>
        <translation>Uživatel</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="26"/>
        <source>Resident Memory</source>
        <translation>Rezidentní paměť</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="26"/>
        <source>%Memory</source>
        <translation>%Paměť</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="26"/>
        <source>Virtual Memory</source>
        <translation>Virtuální paměť</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="27"/>
        <source>Start Time</source>
        <translation>Čas spuštění</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="27"/>
        <source>State</source>
        <translation>Stav</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="27"/>
        <source>Group</source>
        <translation>Skupina</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="28"/>
        <source>Nice</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="28"/>
        <source>CPU Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="28"/>
        <source>Session</source>
        <translation>Sezení</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="28"/>
        <source>Process</source>
        <translation>Proces</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="118"/>
        <source>Processes (%1)</source>
        <translation>Procesy (%1)</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Processes/processes_page.cpp" line="209"/>
        <source>Refresh (%1)</source>
        <translation>Obnovit (%1)</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../stacer/Managers/setting_manager.cpp" line="61"/>
        <source>Dashboard</source>
        <translation>Nástěnka</translation>
    </message>
</context>
<context>
    <name>ResourcesPage</name>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="14"/>
        <source>History of CPU</source>
        <translation>Historie procesoru</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="15"/>
        <source>History of CPU Load Averages</source>
        <translation>Historie průměrů zatížení procesoru</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="16"/>
        <source>History of Disk Read Write</source>
        <translation>Historie čtení/zápisu z disku</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="17"/>
        <source>History of Memory</source>
        <translation>Historie paměti</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="18"/>
        <source>History of Network</source>
        <translation>Historie sítě</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="75"/>
        <source>Read: %1/s Total: %2</source>
        <translation>Gelesen: %1/s Gesamt: %2</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="81"/>
        <source>Write: %1/s Total: %2</source>
        <translation>Čtení: %1/s Celkem: %2</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="118"/>
        <source>%1 Minute Average: %2</source>
        <translation>Průměr za %1 minut(y): %2</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="164"/>
        <source>Download: %1/s Total: %2</source>
        <translation>Stahování: %1/s Celkem: %2</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="169"/>
        <source>Upload: %1/s  Total: %2</source>
        <translation>Nahrávání: %1/s Celkem: %2</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="213"/>
        <source>Swap: %1 (%2%) %3</source>
        <translation>Swap: %1 (%2%) %3</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.cpp" line="222"/>
        <source>Memory: %1 (%2%) %3</source>
        <translation>Paměť: %1 (%2%) %3</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Resources/resources_page.ui" line="14"/>
        <source>Resources</source>
        <translation>Prostředky</translation>
    </message>
</context>
<context>
    <name>ServicesPage</name>
    <message>
        <location filename="../stacer/Pages/Services/services_page.ui" line="14"/>
        <source>Services</source>
        <translation>Služby</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.ui" line="137"/>
        <source>Startup at boot ?</source>
        <translation>Spustit po zapnutí počítače?</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.ui" line="190"/>
        <source>Running Now ?</source>
        <translation>Běží?</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.ui" line="244"/>
        <source>Not Found System Service</source>
        <translation>Systémová služba nebyla nalezena</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.cpp" line="27"/>
        <source>Running Status</source>
        <translation>Stav</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.cpp" line="27"/>
        <source>Running</source>
        <translation>Běžící</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.cpp" line="27"/>
        <source>Not Running</source>
        <translation>Neběžící</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.cpp" line="28"/>
        <source>Startup Status</source>
        <translation>Počáteční stav</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.cpp" line="28"/>
        <source>Enabled</source>
        <translation>Povoleno</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.cpp" line="28"/>
        <source>Disabled</source>
        <translation>Zakázáno</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Services/services_page.cpp" line="75"/>
        <source>System Services (%1)</source>
        <translation>Systémové služby (%1)</translation>
    </message>
</context>
<context>
    <name>SettingsPage</name>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="20"/>
        <source>Settings</source>
        <translation>Nastavení</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="110"/>
        <source>Memory Percent</source>
        <translation>Procenta paměti</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="204"/>
        <source>Disk Percent</source>
        <translation>Procenta disku</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="233"/>
        <source>Disks</source>
        <translation>Disky</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="246"/>
        <source>Language</source>
        <translation>Jazyk</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="259"/>
        <source>Autostart Stacer</source>
        <translation>Automaticky spustit Stacer</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="317"/>
        <source>Alert messages (Show a warning after the specified percentage)</source>
        <translation>Varování (Zobrazovat varování po nastaveném procentu)</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="422"/>
        <source>Start Page</source>
        <translation>Úvodní stránka</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="301"/>
        <source>CPU Percent</source>
        <translation>Procenta procesoru</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="355"/>
        <source>Donate</source>
        <translation>Přispět</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.ui" line="97"/>
        <source>Theme</source>
        <translation>Téma</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.cpp" line="76"/>
        <source>Dashboard</source>
        <translation>Nástěnka</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.cpp" line="76"/>
        <source>Startup Apps</source>
        <translation>Automatické spuštění aplikací</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.cpp" line="76"/>
        <source>System Cleaner</source>
        <translation>Čistič systému</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.cpp" line="77"/>
        <source>Services</source>
        <translation>Služby</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.cpp" line="77"/>
        <source>Processes</source>
        <translation>Procesy</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.cpp" line="77"/>
        <source>Uninstaller</source>
        <translation>Odinstalovávač</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Settings/settings_page.cpp" line="77"/>
        <source>Resources</source>
        <translation>Prostředky</translation>
    </message>
</context>
<context>
    <name>StartupApp</name>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app.ui" line="128"/>
        <source>Edit App</source>
        <translation>Upravit aplikaci</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app.ui" line="150"/>
        <source>Delete App</source>
        <translation>Odstranit aplikaci</translation>
    </message>
</context>
<context>
    <name>StartupAppEdit</name>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="20"/>
        <source>Startup App</source>
        <translation>Automatické spuštění aplikace</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="74"/>
        <source>Save</source>
        <translation>Uložit</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="44"/>
        <source>Fields cannot be left blank. </source>
        <translation>Musíte vyplnit všechna pole. </translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="58"/>
        <source>App Comment</source>
        <translation>Přidat komentář</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="51"/>
        <source>App Name</source>
        <translation>Jméno aplikace</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="97"/>
        <source>Command</source>
        <translation>Příkaz</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_app_edit.ui" line="87"/>
        <source>Application</source>
        <translation>Aplikace</translation>
    </message>
</context>
<context>
    <name>StartupAppsPage</name>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_apps_page.ui" line="201"/>
        <source>Not Found Startup Apps</source>
        <translation>Nebyly nalezeny automaticky se spouštějící aplikace</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_apps_page.ui" line="14"/>
        <source>Startup Apps</source>
        <translation>Automatické spuštění aplikací</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_apps_page.ui" line="101"/>
        <source>Add Startup App</source>
        <translation>Přidat automatické spouštění aplikace</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/StartupApps/startup_apps_page.cpp" line="89"/>
        <source>Startup Applications (%1)</source>
        <translation>Automatické spuštění aplikací (%1)</translation>
    </message>
</context>
<context>
    <name>SystemCleanerPage</name>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="14"/>
        <source>System Cleaner</source>
        <translation>Čistič systému</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="66"/>
        <source>Crash Reports</source>
        <translation>Nahlášení pádu</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="180"/>
        <source>Application Logs</source>
        <translation>Logy aplikací</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="218"/>
        <source>Application Caches</source>
        <translation>Cache aplikací</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="366"/>
        <source>Trash</source>
        <translation>Koš</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="404"/>
        <source>Package Caches</source>
        <translation>Cache balíčků</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="493"/>
        <source>Select All</source>
        <translation>Vybrat vše</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.ui" line="552"/>
        <source> Back</source>
        <translation> Zpět</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.cpp" line="32"/>
        <source>File Name</source>
        <translation>Jméno souboru</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.cpp" line="32"/>
        <source>Size</source>
        <translation>Velikost</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/SystemCleaner/system_cleaner_page.cpp" line="283"/>
        <source>%1 size files cleaned.</source>
        <translation>Vyčištěno %1 souborů.</translation>
    </message>
</context>
<context>
    <name>UninstallerPage</name>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstallerpage.ui" line="14"/>
        <source>Uninstaller</source>
        <translation>Odinstalovávač</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstallerpage.ui" line="90"/>
        <source>Search...</source>
        <translation>Hledat...</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstallerpage.ui" line="192"/>
        <source>Not Found Installed Packages</source>
        <translation>Nenalezeny žádné nainstalované balíčky</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstallerpage.ui" line="140"/>
        <source>Uninstall Selected</source>
        <translation>Odinstalovat vybrané</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/Uninstaller/uninstaller_page.cpp" line="67"/>
        <source>System Installed Packages (%1)</source>
        <translation>Nainstalované balíčky (%1)</translation>
    </message>
</context>
<context>
    <name>UnitySettings</name>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="65"/>
        <source>Applications</source>
        <translation>Aplikace</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="108"/>
        <source>Show &quot;Recently Used&quot; applications</source>
        <translation>Zobrazit &quot;naposledy použité&quot; aplikace</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="134"/>
        <source>Enable search of your files</source>
        <translation>Povolit vyhledávání vašich souborů</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="160"/>
        <source>Show &quot;More Suggestions&quot;</source>
        <translation>Zobrazit &quot;další návrhy&quot;</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="186"/>
        <source>Search</source>
        <translation>Hledat</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="196"/>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="683"/>
        <source>General</source>
        <translation>Obecné</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="229"/>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="660"/>
        <source>Transparency Level</source>
        <translation>Úroveň průhlednosti</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="280"/>
        <source>Behaviour</source>
        <translation>Chování</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="323"/>
        <source>Auto Hide</source>
        <translation>Automatické skrývání</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="339"/>
        <source>Left Side</source>
        <translation>Levá strana</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="380"/>
        <source>Minimize applications with clicking</source>
        <translation>Minimalizovat aplikace kliknutím</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="396"/>
        <source>Top-Left Corner</source>
        <translation>Levý horní roh</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="412"/>
        <source>Reveal Sensitivity</source>
        <translation>Citlivost odhalení</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="438"/>
        <source>Reveal Location</source>
        <translation>Umístění odhalení</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="464"/>
        <source>Launcher</source>
        <translation>Spouštěč</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="474"/>
        <source>Appearance</source>
        <translation>Vzhled</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="507"/>
        <source>Left</source>
        <translation>Vlevo</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="526"/>
        <source>Bottom</source>
        <translation>Dolů</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="542"/>
        <source>Visibility</source>
        <translation>Viditelnost</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="558"/>
        <source>Primary Desktop</source>
        <translation>Hlavní plocha</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="612"/>
        <source>Icon size</source>
        <translation>Velikost ikon</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="628"/>
        <source>All Desktops</source>
        <translation>Všechny plochy</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="644"/>
        <source>Position</source>
        <translation>Pozice</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="726"/>
        <source>Search online sources</source>
        <translation>Hledat online zdroje </translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="752"/>
        <source>Background Blur</source>
        <translation>Rozostření pozadí</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="778"/>
        <source>Panel</source>
        <translation>Panel</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="801"/>
        <source>Indicators</source>
        <translation>Indikátory</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="840"/>
        <source>Date</source>
        <translation>Datum</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="862"/>
        <source>Calendar</source>
        <translation>Kalendář</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="875"/>
        <source>Date &amp; Time</source>
        <translation>Datum &amp; Čas</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="888"/>
        <source>24-Hour Time</source>
        <translation>24-hodinový čas</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="910"/>
        <source>Weekday</source>
        <translation>Den týdne</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="923"/>
        <source>Include</source>
        <translation>Zahrnout</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="945"/>
        <source>Seconds</source>
        <translation>Sekundy</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="958"/>
        <source>Volume</source>
        <translation>Hlasitost</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/unity_settings.ui" line="971"/>
        <source>Show my name</source>
        <translation>Zobrazit mé jméno</translation>
    </message>
</context>
<context>
    <name>WindowManagerSettings</name>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="90"/>
        <source>General</source>
        <translation>Obecné</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="100"/>
        <source>Titlebar Actions</source>
        <translation>Akce záhlaví</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="155"/>
        <source>Right click</source>
        <translation>Kliknutí pravým tlačítkem</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="168"/>
        <source>Double click</source>
        <translation>Dvojklik</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="181"/>
        <source>Middle click</source>
        <translation>Kliknutí prostředním tlačítkem</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="257"/>
        <source>Additional</source>
        <translation>Dodatečné</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="267"/>
        <source>Workspace Settings</source>
        <translation>Nastavení pracovních ploch</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="310"/>
        <source>Vertical workspaces</source>
        <translation>Vertikální pracovní plochy</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="333"/>
        <source>Workspace switcher</source>
        <translation>Přepínač pracovních ploch</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="356"/>
        <source>Horizontal workspaces</source>
        <translation>Horizontální pracovní plochy</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="379"/>
        <source>Focus Behaviour</source>
        <translation>Chování zaměření</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="409"/>
        <source>Focus mode</source>
        <translation>Režim zaměření</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="460"/>
        <source>Raise on click</source>
        <translation>Zaměřit po kliknutí</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="483"/>
        <source>Hardware Acceleration</source>
        <translation>Hardwarová akcelerace</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.ui" line="538"/>
        <source>Text quality</source>
        <translation>Kvalita textu</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="66"/>
        <source>Fast</source>
        <translation>Rychlá</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="66"/>
        <source>Good</source>
        <translation>Dobrá</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="66"/>
        <source>Best</source>
        <translation>Nejlepší</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="68"/>
        <source>Click</source>
        <translation>Kliknutí</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="68"/>
        <source>Sloppy</source>
        <translation>Neupravený</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="68"/>
        <source>Mouse</source>
        <translation>Myš</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="80"/>
        <source>Toggle Shade</source>
        <translation>Přepnout stín</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="80"/>
        <source>Maximize</source>
        <translation>Maximalizovat</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="80"/>
        <source>Maximize Horizontally</source>
        <translation>Horizontálně maximalizovat</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="81"/>
        <source>Maximize Vertically</source>
        <translation>Vertikálně maximalizovat</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="81"/>
        <source>Minimize</source>
        <translation>Minimalizovat</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="82"/>
        <source>None</source>
        <translation>Žádný</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="82"/>
        <source>Lower</source>
        <translation>Nejnižší</translation>
    </message>
    <message>
        <location filename="../stacer/Pages/GnomeSettings/window_manager_settings.cpp" line="82"/>
        <source>Menu</source>
        <translation>Menu</translation>
    </message>
</context>
</TS>
